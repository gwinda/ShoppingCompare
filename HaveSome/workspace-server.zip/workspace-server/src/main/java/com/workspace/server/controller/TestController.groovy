package com.workspace.server.controller

import com.workspace.server.exception.ServerException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.MessageSource
import org.springframework.context.i18n.LocaleContextHolder
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@Controller
class TestController {

    @Autowired MessageSource messageSource

    @GetMapping('/')
    String hello(){
        return '/index.html'
    }

}